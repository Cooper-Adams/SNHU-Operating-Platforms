package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 * Modified during module two by Cooper Adams.
 * Modified during module three by Cooper Adams (11/7/22).
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	
	/*
	 * Holds the next player identifier
	 */
	private static long nextPlayerId = 1;
	
	/*
	 * Holds the next team identifier
	 */
	private static long nextTeamId = 1;

	/**
	 * A private instance of the class. Following the singleton principles,
	 * this will be the only instance of the class.
	 */
	private static GameService gsInstance;

	/**
	 * Default constructor. Private so that new instances of the
	 * game service cannot be instantiated.
	 * 
	 * Accidentally had this as a void function before, but it is now
	 * a proper constructor.
	 */
	private GameService()
	{
		
	}
	
	/**
	 * Gets the GameService instance. If it hasn't been made yet,
	 * it is instantiated.
	 * 
	 * @return the game instance
	 */
	public static GameService getInstance()
	{
		if (gsInstance == null)
		{
			gsInstance = new GameService();
		}
		
		return gsInstance;
	}
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) 
	{
		// Calls getGame(String) to compare game names
		Game game = getGame(name);

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) 
	{
		// a local game instance
		Game game = null;

		//Iterates through the games list and compares IDs. If the ID is
		//a match, return the game instance with the id.
		Iterator<Game> itr = games.iterator();
		
		while(itr.hasNext())
		{
			if (itr.next().getID() == id)
			{
				return itr.next();
			}
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) 
	{
		// a local game instance
		Game game = null;

		// iterator to search through the list
		Iterator<Game> itr = games.iterator();

		//Iterates through the games list comparing the names, and if found,
		//return the game instance with the same name.
		while(itr.hasNext())
		{
			if (itr.next().getName().equalsIgnoreCase(name))
			{
				return itr.next();
			}
		}
		
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() 
	{
		return games.size();
	}
	
	/**
	 * Returns the next player's id and then increments it by one.
	 * 
	 * @return the next player's id and then increments it by one.
	 */
	public long getNextPlayerId()
	{
		return nextPlayerId++;
	}
	
	/**
	 * Returns the next team's id and then increments it by one.
	 * 
	 * @return the next team's id and then increments it by one.
	 */
	public long getNextTeamId()
	{
		return nextTeamId++;
	}
}