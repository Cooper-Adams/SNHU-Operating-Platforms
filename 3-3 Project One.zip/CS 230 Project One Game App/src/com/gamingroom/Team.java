package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	private static List<Player> Players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}
	
	/**
	 * Takes a player's name and iterates over the players list, and if the name
	 * is not a duplicate, add the player to the list.
	 *
	 * @param name The name of the player to be added
	 * @return
	 */
	public Player addPlayer(String name)
	{
		Player player = null;
		
		// iterator to move through teams list
		Iterator<Player> itr = Players.iterator();
						
		// Iterates through the players list comparing names. If a match is 
		// found then that player is returned.
		while(itr.hasNext())
		{
			if (itr.next().getName().equalsIgnoreCase(name))
			{
				return itr.next();
			}
		}
		
		// if not found, make a new player instance and add to list of players
		if (player == null) 
		{
			//Access the game service to get the ID
			GameService service = GameService.getInstance();
			
			player = new Player(service.getNextPlayerId(), name);
			Players.add(player);
		}
	
		// return the new/existing player instance to the caller
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + super.getID() + ", name=" + super.getName() + "]";
	}
}