package com.gamingroom;

/**
 * A singleton service for the game entity
 * 
 * @author Cooper Adams
 */
public class Entity {
	//Entity variables
	private long id;
	private String name;
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Entity()
	{
		
	}
	
	/**
	 * Constructor with an identifier and name
	 */
	public Entity(long id, String name)
	{
		this();
		this.id = id;
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public long getID()
	{
		return id;
	}
	
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	
	@Override
	public String toString()
	{
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}