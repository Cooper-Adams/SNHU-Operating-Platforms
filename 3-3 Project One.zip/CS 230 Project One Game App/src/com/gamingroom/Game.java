package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity{
	
	private static List<Team> Teams = new ArrayList<Team>();
	
	/**
	 * Constructor with an identifier and name
	 * 
	 * Private constructor was removed so the Game class could inherit
	 * the Entity class.
	 */
	public Game(long id, String name) {
		super(id, name);
	}
	
	/**
	 * Takes a team name and iterates over the teams list, and if the name
	 * is not a duplicate, add the team to the list.
	 * 
	 * @param name The name of the team to be added
	 * @return
	 */
	public Team addTeam(String name)
	{
		// a local team instance
		Team team = null;
		
		// iterator to move through teams list
		Iterator<Team> itr = Teams.iterator();
				
		// Iterates through the teams list comparing names. If a match is found
		// then that team is returned.
		while(itr.hasNext())
		{
			if (itr.next().getName().equalsIgnoreCase(name))
			{
				return itr.next();
			}
		}
		
		// if not found, make a new game instance and add to list of teams
		if (team == null) 
		{
			//Access the game service to get the ID
			GameService service = GameService.getInstance();
			
			team = new Team(service.getNextTeamId(), name);
			
			Teams.add(team);
		}

		// return the new/existing team instance to the caller
		return team;
	}

	@Override
	public String toString() {
		return "Game [id=" + super.getID() + ", name=" + super.getName() + "]";
	}
}